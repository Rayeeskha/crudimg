<?php 
	
	class ProductModel extends CI_Model
	{
		
		public function ins($x){
			$name = $this->input->post('name');
			$price = $this->input->post('price');


			$w = array(
				'name'  =>$name,
				'price' =>$price,
				"pimg"  =>$x
			);
			echo json_encode($w);


			$this->db->insert('product', $w);

		}

		public function show(){
			$q = $this->db->get('product');
			$rs = $q->result();
			return $rs;
		}
	}


?>