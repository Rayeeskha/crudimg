<?php include "header.php"; ?>


<div class="container-fluid">
		<div class="row pt-4">
			<div class="col-md-6 col-lg-6 col-sm-6 col-xl-6">
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
				  Create Categtory
				</button>
			</div><br><br><br>

			<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xl-12 pt-4">
				<table class="table table-striped" id="datatable">
				<thead>
							<tr>
								<th>Name</th>
								<th>Price</th>
								<th>Image</th>
							</tr>

							<tbody>
								
							</tbody>
						</thead>
				</table>
			</div>
		</div>
	</div>



<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Category</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      	<form action="<?php echo base_url(); ?>index.php/product/insert" method="post" enctype="multipart/form-data">

			<div class="form-group">
				<p>Name</p>
				<p><input type="text" name="name" class="form-control"></p>
			</div>
			<div class="form-group">
				<p>Price</p>
				<p><input type="text" class="form-control" name="price"></p>
			<div>
			<div class="form-group">
				<p>Products image</p>
				<p><input type="file" class="form-control" name="pimg"></p>
			</div>
			
			
		</form>
        
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
      	<button type="submit" value="Save Data" class="btn btn-primary">Save Data</button>
      	
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<script type="text/javascript">
	$(document).ready( function () {
    $('#datatable').DataTable();
} );
</script>
