<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<div class="container">
	<p>Products</p>
	<a href="<?php echo base_url(); ?>index.php/product/addProduct" class="btn btn-info">Add New</a>
<table class="table table-bordered">
	<thead>
		<tr>
			<th>Name</th>
			<th>Price</th>
			<th>Image</th>
		</tr>

		<tbody>
			<?php 
				foreach($row as $r){
			?>

			<tr>
				
					<td><?php echo $r->name ?> </td>
					<td><?php echo $r->price ?> </td>
					<td ><img  src="<?php echo base_url(); ?>product_img/<?php echo $r->pimg; ?>" style="width: 100px;" ></td>
					
				
			</tr>
		<?php } ?>
		</tbody>
	</thead>
</table>
</div>