<?php 

class Product extends CI_Controller
{
	public function addproduct(){
		$this->load->view("addProduct");

	}
	public function index(){
		$this->load->view("addProduct");
	}

	public function insert(){
		$config['upload_path']     = './product_img';
		$config['allowed_types']   = 'png|jpg|jpeg|gif|bmp';
		$config['max_size']        = 100;
		$this->load->library('upload',$config);

		if (!$this->upload->do_upload('pimg')) {
			# code...
			echo "Error";
		}else{
			$filedata = $this->upload->data();
			$filename = $filedata['file_name'];


			$this->ProductModel->ins($filename);
			redirect(base_url() . 'index.php/product/view');
		}
		
	}

	public function view(){
		$res = $this->ProductModel->show();
		$w = array(
				'row' => $res
			);
		$this->load->view("showProduct", $w);

	}
	
}




?>