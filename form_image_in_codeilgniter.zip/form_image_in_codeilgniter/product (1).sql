-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2020 at 01:44 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `image_uploading_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `pimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `pimg`) VALUES
(1, 'testing team', '350', 'loader4_(2)1.jpg'),
(2, 'testing', '500', 'gluten-free-diet-logo-celiac-disease-wheat-vector-restaurant-logo-thumbnail7.jpg'),
(3, 'testing', '500', 'gluten-free-diet-logo-celiac-disease-wheat-vector-restaurant-logo-thumbnail8.jpg'),
(4, 'testing', '500', 'gluten-free-diet-logo-celiac-disease-wheat-vector-restaurant-logo-thumbnail9.jpg'),
(5, 'testing', '500', 'hyderaabd1.png'),
(6, 'testing', '500', 'hyderaabd2.png'),
(7, 'testing', '500', 'hyderaabd3.png'),
(8, 'testing team', '500', 'hyderaabd4.png'),
(9, 'testing', '500', '94dd9d7d-33cf-4071-a526-83b080b80352.jpg'),
(10, 'testing', '500', '94dd9d7d-33cf-4071-a526-83b080b80352_185x73.jpg'),
(11, 'testing', '500', 'gluten-free-diet-logo-celiac-disease-wheat-vector-restaurant-logo-thumbnail10.jpg'),
(12, 'testing', '500', 'gluten-free-diet-logo-celiac-disease-wheat-vector-restaurant-logo-thumbnail11.jpg'),
(13, 'testing', '500', 'hyderaabd5.png'),
(14, 'testing', '500', 'gluten-free-diet-logo-celiac-disease-wheat-vector-restaurant-logo-thumbnail12.jpg'),
(15, 'testing', '500', 'logo-2.png'),
(16, 'testing', '500', '94dd9d7d-33cf-4071-a526-83b080b80352_185x731.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
